package com.app.pojos;

public enum CustomerType {
	SENDER, RECEIVER
}
