package com.app.pojos;

public enum ServiceType {
	STANDARD, EXPRESS
}
