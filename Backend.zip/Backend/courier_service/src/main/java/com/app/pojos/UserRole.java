package com.app.pojos;

public enum UserRole {
	ROLE_ADMIN, ROLE_EMPLOYEE, ROLE_CLIENT
}
