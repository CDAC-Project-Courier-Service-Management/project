package com.app.pojos;

public enum ComplaintStatus {
	OPEN, UNDER_REVIEW, RESOLVED, CLOSED, PENDING, REJECTED
}
