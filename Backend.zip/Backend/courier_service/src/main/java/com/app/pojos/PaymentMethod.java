package com.app.pojos;

public enum PaymentMethod {
	CREDIT, DEBIT, UPI
}
